{{/*
Chart
*/}}
{{- define "vertical-pod-autoscaler.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "vertical-pod-autoscaler.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "vertical-pod-autoscaler.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "vertical-pod-autoscaler.labels" -}}
helm.sh/chart: {{ include "vertical-pod-autoscaler.chart" . }}
{{ include "vertical-pod-autoscaler.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- with .Values.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{- define "vertical-pod-autoscaler.selectorLabels" -}}
app.kubernetes.io/name: {{ include "vertical-pod-autoscaler.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}


{{/*
admissionController
*/}}
{{- define "vertical-pod-autoscaler.admissionController.fullname" -}}
{{ include "vertical-pod-autoscaler.fullname" . }}-admission-controller
{{- end }}

{{- define "vertical-pod-autoscaler.admissionController.labels" -}}
{{ include "vertical-pod-autoscaler.labels" . }}
app.kubernetes.io/component: admission-controller
app.kubernetes.io/component-instance: {{ .Release.Name }}-admission-controller
{{- end }}

{{- define "vertical-pod-autoscaler.admissionController.selectorLabels" -}}
{{ include "vertical-pod-autoscaler.selectorLabels" . }}
app.kubernetes.io/component: admission-controller
{{- end }}

{{- define "vertical-pod-autoscaler.admissionController.image" -}}
{{- printf "%s:%s" .Values.admissionController.image.repository (default .Chart.AppVersion .Values.admissionController.image.tag) }}
{{- end }}

{{/*
Create the name of the tls secret to use
*/}}
{{- define "vertical-pod-autoscaler.admissionController.tls.secretName" -}}
{{- if .Values.admissionController.tls.secretName -}}
    {{ .Values.admissionController.tls.secretName }}
{{- else -}}
    {{- printf "%s-%s" (include "vertical-pod-autoscaler.admissionController.fullname" .) "tls" | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
admissionController webhook
*/}}

{{- define "vertical-pod-autoscaler.admissionController.webhook.configName" -}}
{{ include "vertical-pod-autoscaler.fullname" . }}-webhook-config
{{- end }}

{{/*
admissionController certManager
*/}}
{{- define "vertical-pod-autoscaler.admissionController.certManager.certName" -}}
{{ include "vertical-pod-autoscaler.fullname" . }}-webhook-cert
{{- end }}

{{- define "vertical-pod-autoscaler.admissionController.certManager.issuerName" -}}
{{ include "vertical-pod-autoscaler.fullname" . }}-selfsigned
{{- end }}

{{- define "vertical-pod-autoscaler.admissionController.certManager.caName" -}}
{{ include "vertical-pod-autoscaler.fullname" . }}-webhook-ca
{{- end }}

{{- define "vertical-pod-autoscaler.admissionController.certManager.caIssuerName" -}}
{{ include "vertical-pod-autoscaler.fullname" . }}-ca
{{- end }}

{{/*
admissionController certGen
*/}}
{{- define "vertical-pod-autoscaler.admissionController.certGen.fullname" -}}
{{ include "vertical-pod-autoscaler.fullname" . }}-admission-certgen
{{- end }}

{{- define "vertical-pod-autoscaler.admissionController.certGen.labels" -}}
{{ include "vertical-pod-autoscaler.labels" . }}
app.kubernetes.io/component: admission-certgen
{{- end }}


{{/*
updater
*/}}
{{- define "vertical-pod-autoscaler.updater.fullname" -}}
{{ include "vertical-pod-autoscaler.fullname" . }}-updater
{{- end }}

{{- define "vertical-pod-autoscaler.updater.labels" -}}
{{ include "vertical-pod-autoscaler.labels" . }}
app.kubernetes.io/component: updater
app.kubernetes.io/component-instance: {{ .Release.Name }}-updater
{{- end }}

{{- define "vertical-pod-autoscaler.updater.selectorLabels" -}}
{{ include "vertical-pod-autoscaler.selectorLabels" . }}
app.kubernetes.io/component: updater
{{- end }}

{{- define "vertical-pod-autoscaler.updater.image" -}}
{{- printf "%s:%s" .Values.updater.image.repository (default .Chart.AppVersion .Values.updater.image.tag) }}
{{- end }}

{{- define "vertical-pod-autoscaler.updater.leaderElectionEnabled" -}}
{{- if and (eq .Values.updater.leaderElection.enabled nil) (gt (int .Values.updater.replicas) 1) -}}
true
{{- else if .Values.updater.leaderElection.enabled -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}


{{/*
Create the name of the namespace to use
*/}}
{{- define "common.names.namespace" -}}
{{- default .Release.Namespace .Values.namespaceOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}


{{/*
recommender
*/}}
{{- define "vertical-pod-autoscaler.recommender.fullname" -}}
{{ include "vertical-pod-autoscaler.fullname" . }}-recommender
{{- end }}

{{- define "vertical-pod-autoscaler.recommender.labels" -}}
{{ include "vertical-pod-autoscaler.labels" . }}
app.kubernetes.io/component: recommender
app.kubernetes.io/component-instance: {{ .Release.Name }}-recommender
{{- end }}

{{- define "vertical-pod-autoscaler.recommender.selectorLabels" -}}
{{ include "vertical-pod-autoscaler.selectorLabels" . }}
app.kubernetes.io/component: recommender
{{- end }}

{{- define "vertical-pod-autoscaler.recommender.image" -}}
{{- printf "%s:%s" .Values.recommender.image.repository (default .Chart.AppVersion .Values.recommender.image.tag) }}
{{- end }}
